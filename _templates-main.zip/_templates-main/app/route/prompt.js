const fs = require("fs");

// convert any string to camelCase
var toCamelCase = function (str) {
  return str
    .toLowerCase()
    .replace(/['"]/g, "")
    .replace(/\W+/g, " ")
    .replace(/ (.)/g, function ($1) {
      return $1.toUpperCase();
    })
    .replace(/ /g, "");
};

module.exports = {
  prompt: ({ inquirer }) => {
    const questions = [
      {
        type: "input",
        name: "routeName",
        message: "Route name:",
      },
      {
        type: "input",
        name: "routeVersion",
        message: "Version",
      },
    ];

    return inquirer.prompt(questions).then((answers) => {
      // * Check whether this route already exist
      let { routeName, routeVersion } = answers;

      if (!routeName || !routeVersion) {
        return Promise.reject("Answers can't be empty");
      }

      let routePath = `${process.cwd()}/src/routes/v${routeVersion}/${toCamelCase(
        routeName
      )}.route.ts`;

      if (fs.existsSync(routePath)) {
        //file exists
        return Promise.reject("Route already exist");
      }

      return Object.assign({}, answers);
    });
  },
};
