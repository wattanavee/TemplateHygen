module.exports = [
  {
    type: "input",
    name: "name",
    message: "Interface name:",
  },
];
