const fs = require("fs");

try {
  console.log(require.resolve("dotenv"));
} catch (e) {
  console.error("Please init app and install dependencies first");
  console.error(e.message);
  process.exit(e.code);
}

const dotenv = require("dotenv").config();

// convert any string to camelCase
var toCamelCase = function (str) {
  return str
    .toLowerCase()
    .replace(/['"]/g, "")
    .replace(/\W+/g, " ")
    .replace(/ (.)/g, function ($1) {
      return $1.toUpperCase();
    })
    .replace(/ /g, "");
};

module.exports = {
  prompt: ({ inquirer }) => {
    const questions = [
      {
        type: "input",
        name: "envName",
        message: "Environment name:",
      },
    ];

    return inquirer.prompt(questions).then((answers) => {
      // * Check whether this route already exist
      let { envName } = answers;

      if (!envName) {
        return Promise.reject("Answers can't be empty");
      }

      // * Check env with that name already exist
      if (process.env[envName.toUpperCase()] !== undefined) {
        return Promise.reject("Environment name already exist");
      }

      return Object.assign({}, answers);
    });
  },
};
