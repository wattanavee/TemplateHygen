module.exports = [
  {
    type: "input",
    name: "serviceName",
    message: "Service name:",
  },
];
